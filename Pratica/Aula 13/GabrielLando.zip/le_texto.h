#ifndef _LE_TEXTO_H_
#define _LE_TEXTO_H_

#include <stdio.h>
#include <string.h>

void le_texto(char texto[], int size_texto);

#endif
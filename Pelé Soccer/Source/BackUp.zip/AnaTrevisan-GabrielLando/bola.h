#ifndef _BOLA_H_
#define _BOLA_H_

#include "lib.h"

void bola_up(COORD_BOLA *bola);

void bola_down(COORD_BOLA *bola);

void bola_dir(COORD_BOLA *bola);

void bola_esq(COORD_BOLA *bola);

#endif
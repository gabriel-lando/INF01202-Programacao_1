#include "lib.h"

int main(){

	iniciar();

	return 0;
}
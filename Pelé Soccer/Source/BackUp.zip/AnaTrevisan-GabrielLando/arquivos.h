#ifndef _ARQUIVOS_H_
#define _ARQUIVOS_H_

#include "lib.h"

int formacao(int **form1, int **form2, char arq[]); //Retorna a quantidade de jogadores no time

void recordes(SCORE score);

#endif
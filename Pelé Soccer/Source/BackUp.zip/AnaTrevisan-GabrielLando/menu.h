#ifndef _MENU_H_
#define _MENU_H_

#include "lib.h"

int menu_curs(int menu_x, int menu_y, int qtd);

#endif
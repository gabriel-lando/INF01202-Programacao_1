#ifndef _JOGO_H_
#define _JOGO_H_

#include "lib.h"

void iniciar();

#endif